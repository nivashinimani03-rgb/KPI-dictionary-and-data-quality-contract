# Data Quality Contract — Retail Orders Dataset

**Dataset:** `retail-orders-raw.csv`
**Decision owner:** Revenue Operations Lead (accountable for every KPI in `KPI_Dictionary.xlsx`)
**Data steward:** Revenue Ops Analyst (runs the checks, escalates failures)
**Grain:** one row per valid, de-duplicated `order_id`
**Companion artifacts:** `KPI_Dictionary.xlsx` (KPI definitions + live formula calc) · `data_profile_notebook.ipynb` (executable checks that produce the numbers below)

This contract states what "trustworthy" means for this dataset, in numbers a pipeline can test —
not just in words. Every threshold below is checked by `data_profile_notebook.ipynb`, and the
same logic is re-implemented as live spreadsheet formulas in `KPI_Dictionary.xlsx` for a
non-technical audit trail.

---

## 1. What "good" means, dimension by dimension

| Dimension | Definition for this dataset | Threshold | Result on the raw file (2026-09-13 run) |
|---|---|---|---|
| **Completeness** | Every required field (`order_id`, `order_date`, `customer_segment`, `city`, `category`, `quantity`, `unit_price`, `discount_pct`, `payment_status`) is non-null and non-blank | ≥ 98% per column | **FAIL** — `order_date`, `city`, `discount_pct` each at 91.7% |
| **Uniqueness** | No two rows share an `order_id` | 0 duplicate `order_id` rows | **FAIL** — `RT-1004` appears twice (fully identical rows) |
| **Validity** | Each field matches the rule in `retail-data-dictionary.csv` (ISO date within range, positive integer quantity, 0–100 discount, allowed category/segment/payment enum, non-negative price) | ≥ 90% of rows pass every field rule | **FAIL** — 5 of 11 rows (45%) fail at least one rule |
| **Consistency** | Categorical fields (`customer_segment`, `payment_status`) use one consistent casing so they group correctly in KPIs | 0 values needing case normalization | **FAIL (raw)** — `student` (should be `Student`), `paid` (should be `Paid`) |
| **Freshness** | Most recent valid `order_date` is recent enough for daily reporting | ≤ 7 days old at run time | **FAIL** — most recent valid order is 238 days old |

*(Full row-level evidence for every FAIL — which `order_id`, which field, which rule — is in
Section 3 of `data_profile_notebook.ipynb`.)*

## 2. Known issues in this file, named explicitly

| order_id | Issue | Dimension affected |
|---|---|---|
| RT-1002 | `order_date` in `DD/MM/YYYY` instead of ISO `YYYY-MM-DD`; `payment_status` lowercase `paid` | Validity, Consistency |
| RT-1003 | `customer_segment` lowercase `student`; `discount_pct` missing | Validity, Completeness |
| RT-1004 | Row duplicated exactly (appears twice) | Uniqueness |
| RT-1005 | `city` missing | Completeness |
| RT-1006 | `order_date` has an impossible month (`2026-13-10`); `quantity` is negative (`-1`) | Validity |
| RT-1007 | `discount_pct` out of range (`105`) | Validity |
| RT-1008 | `quantity` is non-numeric text (`"two"`) | Validity |
| RT-1011 | `order_date` missing | Completeness, Validity |

Only **RT-1001, RT-1009, and RT-1010** pass every rule as received.

## 3. Failure thresholds and what they trigger

| Trigger | Threshold breached | Action | Owner | SLA |
|---|---|---|---|---|
| **Block** | Any required column drops below 90% completeness, **or** any duplicate `order_id` is found | Halt the KPI refresh; do not publish revenue/order KPIs on this file | Revenue Ops Analyst | Immediate — before next scheduled refresh |
| **Warn** | A column sits between the 90–98% completeness band, **or** validity pass-rate is between 80–90% | Publish KPIs with a "data quality caveat" banner; open a ticket | Revenue Ops Analyst → notifies Finance Ops Lead | Within 24 hours |
| **Auto-fix, then proceed** | Categorical values only need case normalization (Consistency dimension) | Apply `PROPER(TRIM())` normalization step before KPI load; log the affected row count | Revenue Ops Analyst | Same run, no escalation needed |
| **Escalate** | Freshness SLA breached (no valid order in > 7 days), **or** the same Block trigger repeats on 2 consecutive scheduled runs | Escalate to Revenue Operations Lead; investigate upstream source system | Revenue Ops Analyst → Revenue Operations Lead | Within 4 business hours |
| **Executive escalation** | Net Revenue or Order Volume KPI would swing by more than 20% purely because of excluded bad rows (i.e., data quality — not real demand — is driving the number) | Freeze KPI publication; joint review with Finance Ops Lead and Revenue Operations Lead before any number goes to leadership | Revenue Operations Lead | Same business day |

## 4. Ownership and refresh

- **Data steward** (Revenue Ops Analyst): runs `data_profile_notebook.ipynb` on every new file drop, files the scorecard, applies the Consistency auto-fix, and raises Block/Warn tickets.
- **Decision owner** (Revenue Operations Lead): owns the KPI Dictionary, approves any threshold change in this contract, and is the escalation point for Block and Executive-escalation triggers.
- **Review cadence:** this contract is re-validated whenever a KPI is added or a new upstream field appears, and at minimum every quarter.

## 5. How to verify compliance

1. Run `data_profile_notebook.ipynb` top to bottom against the latest file.
2. Check the **Data Quality Scorecard** (final section of the notebook) — every dimension must show `PASS` before KPIs are published.
3. Cross-check headline KPIs against the **Live KPI Calc** sheet in `KPI_Dictionary.xlsx` — both are built independently from the same raw file and should agree once the Consistency auto-fix is applied.
4. Any FAIL still present after the Block/Warn/Escalate actions above is a contract breach — log it and follow the Escalate row.
